package com.example.opdsaggregator.data
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.URLEncoder
data class OpdsCatalog(
    val id: String,
    val name: String,
    val searchUrlTemplate: String,
    val apiKey: String? = null
)
data class BookItem(
    val id: String,
    val title: String,
    val author: String,
    val coverUrl: String?,
    val downloadUrl: String?,
    val sourceCatalogName: String
)
class FederatedOpdsRepository(private val client: OkHttpClient = OkHttpClient()) {
    fun searchAllCatalogs(catalogs: List<OpdsCatalog>, query: String): Flow<List<BookItem>> = channelFlow {
        val encodedQuery = withContext(Dispatchers.IO) { URLEncoder.encode(query, "UTF-8") }
        catalogs.forEach { catalog ->
            launch(Dispatchers.IO) {
                try {
                    val targetUrl = catalog.searchUrlTemplate.replace("{searchTerms}", encodedQuery)
                    val requestBuilder = Request.Builder().url(targetUrl)
                    if (!catalog.apiKey.isNullOrEmpty()) {
                        requestBuilder.header("Authorization", "Bearer ${catalog.apiKey}")
                    }
                    client.newCall(requestBuilder.build()).execute().use { response ->
                        if (response.isSuccessful) {
                            val parsedBooks = parseOpdsXml(response.body?.string().orEmpty(), catalog.name)
                            if (parsedBooks.isNotEmpty()) send(parsedBooks)
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }
    private fun parseOpdsXml(xml: String, catalogName: String): List<BookItem> {
        val books = mutableListOf<BookItem>()
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xml))
        var eventType = parser.eventType
        var title = ""; var author = ""; var id = ""; var cover: String? = null; var download: String? = null; var insideEntry = false
        while (eventType != XmlPullParser.END_DOCUMENT) {
            val tagName = parser.name?.lowercase() ?: ""
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (tagName == "entry") { insideEntry = true; title = ""; author = ""; id = ""; cover = null; download = null }
                    else if (insideEntry) {
                        when (tagName) {
                            "title" -> title = parser.nextText().trim()
                            "name" -> author = parser.nextText().trim()
                            "id" -> id = parser.nextText().trim()
                            "link" -> {
                                val rel = parser.getAttributeValue(null, "rel")
                                val href = parser.getAttributeValue(null, "href")
                                val type = parser.getAttributeValue(null, "type")
                                if (rel?.contains("image") == true || rel?.contains("thumbnail") == true) cover = href
                                else if (rel?.contains("acquisition") == true || type?.contains("epub") == true) download = href
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (tagName == "entry" && insideEntry) {
                        if (title.isNotEmpty()) books.add(BookItem(id.ifEmpty { title }, title, author.ifEmpty { "Unknown Author" }, cover, download, catalogName))
                        insideEntry = false
                    }
                }
            }
            eventType = parser.next()
        }
        return books
    }
}