package com.example.opdsaggregator.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
val InkBlack = Color(0xFF141312)
val InkMuted = Color(0xFF6B6661)
val InkFaint = Color(0xFFA8A29E)
val PaperBackgroundLight = Color(0xFFFAF7F2)
val PaperCardLight = Color(0xFFFFFFFF)
val PaperBorderLight = Color(0xFFE7E2DA)
val AccentTerracotta = Color(0xFFB45309)
val PaperBackgroundDark = Color(0xFF191816)
val PaperCardDark = Color(0xFF22201D)
val PaperBorderDark = Color(0xFF33302B)
val MarginTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 1.2.sp)
)
@Composable
fun MarginTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colorScheme = if (darkTheme) darkColorScheme(background = PaperBackgroundDark, surface = PaperCardDark, outline = PaperBorderDark, onBackground = PaperBackgroundLight, onSurface = PaperBackgroundLight, primary = AccentTerracotta)
    else lightColorScheme(background = PaperBackgroundLight, surface = PaperCardLight, outline = PaperBorderLight, onBackground = InkBlack, onSurface = InkBlack, primary = AccentTerracotta)
    MaterialTheme(colorScheme = colorScheme, typography = MarginTypography, content = content)
}