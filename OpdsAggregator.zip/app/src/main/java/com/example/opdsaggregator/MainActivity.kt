package com.example.opdsaggregator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.opdsaggregator.ui.screens.MarginCatalogSearchScreen
import com.example.opdsaggregator.ui.theme.MarginTheme
import com.example.opdsaggregator.viewmodel.CatalogSearchViewModel
class MainActivity : ComponentActivity() {
    private val viewModel: CatalogSearchViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MarginTheme {
                MarginCatalogSearchScreen(
                    viewModel = viewModel,
                    onBookSelected = { book -> }
                )
            }
        }
    }
}