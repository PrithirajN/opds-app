package com.example.opdsaggregator.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.opdsaggregator.data.BookItem
import com.example.opdsaggregator.data.FederatedOpdsRepository
import com.example.opdsaggregator.data.OpdsCatalog
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
data class SearchScreenState(
    val query: String = "",
    val isLoading: Boolean = false,
    val books: List<BookItem> = emptyList(),
    val catalogs: List<OpdsCatalog> = listOf(
        OpdsCatalog("1", "Standard Ebooks", "https://standardebooks.org/opds/all?query={searchTerms}"),
        OpdsCatalog("2", "Feedbooks", "https://catalog.feedbooks.com/search.atom?query={searchTerms}"),
        OpdsCatalog("3", "Project Gutenberg", "https://m.gutenberg.org/ebooks/search.opds/?query={searchTerms}")
    )
)
class CatalogSearchViewModel(private val repository: FederatedOpdsRepository = FederatedOpdsRepository()) : ViewModel() {
    private val _uiState = MutableStateFlow(SearchScreenState())
    val uiState: StateFlow<SearchScreenState> = _uiState.asStateFlow()
    private var searchJob: Job? = null
    fun onQueryChanged(newQuery: String) { _uiState.value = _uiState.value.copy(query = newQuery) }
    fun executeSearch() {
        val query = _uiState.value.query.trim()
        if (query.isEmpty()) return
        searchJob?.cancel()
        _uiState.value = _uiState.value.copy(isLoading = true, books = emptyList())
        searchJob = viewModelScope.launch {
            repository.searchAllCatalogs(_uiState.value.catalogs, query).collect { newBatch ->
                _uiState.value = _uiState.value.copy(books = (_uiState.value.books + newBatch).distinctBy { it.title + it.author })
            }
            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }
}