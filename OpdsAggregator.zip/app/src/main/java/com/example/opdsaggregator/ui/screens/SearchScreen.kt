package com.example.opdsaggregator.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.opdsaggregator.data.BookItem
import com.example.opdsaggregator.ui.theme.InkFaint
import com.example.opdsaggregator.ui.theme.InkMuted
import com.example.opdsaggregator.ui.theme.InkBlack
import com.example.opdsaggregator.viewmodel.CatalogSearchViewModel
@Composable
fun MarginCatalogSearchScreen(viewModel: CatalogSearchViewModel, onBookSelected: (BookItem) -> Unit = {}) {
    val state by viewModel.uiState.collectAsState()
    val focusManager = LocalFocusManager.current
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 20.dp)) {
            Spacer(modifier = Modifier.height(24.dp))
            Text("Federated Library", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
            Text("Searching across ${state.catalogs.size} connected OPDS sources", style = MaterialTheme.typography.bodyMedium, color = InkMuted, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
            MarginSearchBar(query = state.query, onQueryChange = viewModel::onQueryChanged, onSearch = { focusManager.clearFocus(); viewModel.executeSearch() })
            Spacer(modifier = Modifier.height(16.dp))
            if (state.isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.background)
                Spacer(modifier = Modifier.height(16.dp))
            }
            if (state.books.isEmpty() && !state.isLoading) {
                EmptyStateView()
            } else {
                LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
                    items(items = state.books, key = { it.id + it.sourceCatalogName }) { book -> MarginBookCoverCard(book = book, onClick = { onBookSelected(book) }) }
                }
            }
        }
    }
}
@Composable
fun MarginSearchBar(query: String, onQueryChange: (String) -> Unit, onSearch: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().shadow(3.dp, RoundedCornerShape(12.dp), ambientColor = InkFaint).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)).padding(horizontal = 16.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Search, contentDescription = null, tint = InkMuted, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            BasicTextField(value = query, onValueChange = onQueryChange, singleLine = true, cursorBrush = SolidColor(MaterialTheme.colorScheme.primary), textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { onSearch() }), modifier = Modifier.weight(1f), decorationBox = { innerTextField -> if (query.isEmpty()) Text("Find titles, authors across feeds...", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp, color = InkFaint)); innerTextField() })
            if (query.isNotEmpty()) Icon(Icons.Rounded.Clear, contentDescription = "Clear search", tint = InkMuted, modifier = Modifier.size(18.dp).clickable { onQueryChange("") })
        }
    }
}
@Composable
fun MarginBookCoverCard(book: BookItem, onClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box(modifier = Modifier.fillMaxWidth().aspectRatio(0.66f).shadow(6.dp, RoundedCornerShape(6.dp), spotColor = InkBlack.copy(alpha = 0.25f)).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surface).border(0.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))) {
            if (!book.coverUrl.isNullOrEmpty()) AsyncImage(model = book.coverUrl, contentDescription = "Cover", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Box(modifier = Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) { Text(book.title, style = MaterialTheme.typography.titleLarge.copy(fontSize = 14.sp), color = InkMuted, maxLines = 4, overflow = TextOverflow.Ellipsis) }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(book.sourceCatalogName.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(modifier = Modifier.height(2.dp))
        Text(book.title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(modifier = Modifier.height(2.dp))
        Text(book.author, style = MaterialTheme.typography.bodyMedium, color = InkMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
@Composable
fun EmptyStateView() {
    Box(modifier = Modifier.fillMaxSize().padding(bottom = 64.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("No Volumes Loaded", style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif), color = InkMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Enter a query to federate across all registered servers.", style = MaterialTheme.typography.bodyMedium, color = InkFaint)
        }
    }
}